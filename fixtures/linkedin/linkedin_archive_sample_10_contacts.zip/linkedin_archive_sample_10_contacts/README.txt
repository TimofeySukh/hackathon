Sample LinkedIn archive with synthetic data for testing.

Files:
- Connections.csv: 10 sample LinkedIn connections
- Contacts.csv: 10 sample email contacts
- Messages.csv: 5 sample message rows
- Profile.csv: one sample profile row

All names, URLs, emails, companies, profile details, and messages are fully synthetic mock sample data.
